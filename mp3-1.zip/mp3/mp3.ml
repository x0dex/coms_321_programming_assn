(* CS342 - Spring 2024
 * MP3
 *
 * Please keep in mind that there may be more than one
 * way to solve a problem.  You will want to change how a number of these start.
 *)


(*Problem 1*)
let rec product l = raise(Failure "Function not implemented yet.")

(*Problem 2*)
let rec double_all l = raise(Failure "Function not implemented yet.")

(*Problem 3*)
let rec pair_with_all x l = raise(Failure "Function not implemented yet.")

(*Problem 4*)
let rec interleave l1 l2 = raise(Failure "Function not implemented yet.")

(*Problem 5*)
let rec even_count_fr l = raise(Failure "Function not implemented yet.")

(*Problem 6*)
let rec pair_sums l = raise(Failure "Function not implemented yet.")

(*Problem 7*)
let rec remove_even list = raise(Failure "Function not implemented yet.")

(*Problem 8*)
let rec sift p l = raise(Failure "Function not implemented yet.")

(*Problem 9*)
let rec even_count_tr l = raise(Failure "Function not implemented yet.")

(*Problem 10*)
let rec count_element l m = raise(Failure "Function not implemented yet.")

(*Problem 11*)
let rec all_nonneg list = raise(Failure "Function not implemented yet.")

(*Problem 12*)
let rec split_sum l f = raise(Failure "Function not implemented yet.")

(*Problem 13*)
let even_count_fr_base = 101
let even_count_fr_rec x rec_val = raise(Failure "Function not implemented yet.")
  
(*Problem 14*)
let pair_sums_map_arg p = raise(Failure "Function not implemented yet.")

(*Problem 15*)
let remove_even_base = [101]
let remove_even_rec n r = raise(Failure "Function not implemented yet.")

(*Problem 16*)
let even_count_tr_start = (101)
let even_count_tr_step acc_val x = raise(Failure "Function not implemented yet.")

(*Problem 17*)
let split_sum_start = ((101),(101))
let split_sum_step f = raise(Failure "Function not implemented yet.")
