(* CS342
 * myFirstFun
 *
 * Please keep in mind that there may be more than one
 * way to solve a problem.  You may want to change how this starts.
 *)

open Common

(*Problem 1*)
let x = 0.0 (* You want to change this *)

let square_plus_x y = raise (Failure "Function not implemented yet.")
