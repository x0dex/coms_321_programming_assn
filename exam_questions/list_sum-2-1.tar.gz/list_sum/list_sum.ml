open Common

(* CS421 - Spring 2023 list_sum
 * 
 * Please keep in mind that there may be more than one way to solve a
 * problem. You will want to change how a number of these start.
 *)

(*****************************
* Continuation Passing Style *
*****************************)

(***** Problem 6a: Recursion & CPS ******)
let rec list_sum l = raise(Failure "Function not implemented yet.")

(***** Problem 6b: Recursion & CPS ******)
let rec list_sumk l k = raise(Failure "Function not implemented yet.")
