(* CS342
 * binTree_find
 *
 * Please keep in mind that there may be more than one
 * way to solve a problem. You may want to create
 * helper functions.
 *)

open Common

let rec find n tree = raise(Failure "Not implemented yet")
