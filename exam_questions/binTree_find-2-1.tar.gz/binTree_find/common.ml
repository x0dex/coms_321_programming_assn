(* File: common.ml *)

type 'a tree =
    Leaf of (int * 'a)
  | Node of ('a tree * 'a tree)
