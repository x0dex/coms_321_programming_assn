(* CS421 - Fall 2017
 * var
 *
 * Please keep in mind that there may be more than one
 * way to solve a problem.  You may want to change how this starts.
 *)

open Common

let rec count_const_in_exp exp =  raise (Failure "Not implemented yet.")
