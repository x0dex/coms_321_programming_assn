(* File: frozen.ml
 *)

open Common

  
(* Problem 1: string_variable_declaration 1 *)

let frozen = "This is wrong.\nPut the right thing here!\n"
