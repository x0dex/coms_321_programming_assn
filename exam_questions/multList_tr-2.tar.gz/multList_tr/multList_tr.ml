(* CS342 multList_tr
 * 
 * Please keep in mind that there may be more than one way to solve a
 * problem.  You will want to change how a number of these start.
 *)

(*************************
* Patterns of Recursion *
*************************)

(*********************
 * Tail Recursion *
 *********************)

(* Problems *)
let rec multList_tr l = raise(Failure "Function not implemented yet.")
let multList_tr_start = 1337 (* You may need to change this *)
let multList_tr_step x rec_val = raise(Failure "Function not implemented yet.")
