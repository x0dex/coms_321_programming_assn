(* cs342
 * sum_evens_less_eq
 *
 * Please keep in mind that there may be more than one
 * way to solve a problem.  You may want to change how this starts.
 *)


(*Problem*)
let rec sum_evens_less_eq n = raise(Failure "Function not implemented yet.")
